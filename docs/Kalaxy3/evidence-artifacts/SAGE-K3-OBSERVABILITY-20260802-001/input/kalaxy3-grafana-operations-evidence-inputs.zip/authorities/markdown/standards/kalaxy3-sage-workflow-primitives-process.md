# Kalaxy3 SAGE Workflow Primitives and Composition Process

## Purpose

Kalaxy3 workflow automation MUST accumulate engineering experience rather than
recreating repository, Git, discovery, lifecycle, validation, Makefile,
logging, and evidence behavior in each downloaded helper.

New operator workflows are thin compositions of repository-owned, versioned
primitives. The framework begins at pilot maturity. No historical execution
count is fabricated or inferred from similar one-off scripts.

## Primitive design contract

Every primitive has one responsibility and a stable typed interface. Its
registry entry declares:

- version and evidence-based maturity;
- side effects and mutation boundary;
- idempotency and retry behavior;
- structured logging behavior;
- fail-closed behavior;
- runtime-path tests.

Primitive implementations use dependency injection for command execution and
event logging. They do not use `shell=True`. Commands have explicit argument
vectors, working directories, timeouts, expected return codes, and
secret-redaction inputs.

## Structured logging

Workflow events are append-only JSONL records under the operator's local SAGE
state directory. Events store labels and SHA-256 digests, not raw command
arguments or raw terminal output.

Every event identifies the workflow, sequence, primitive, primitive version,
step, status, and timestamp. Mutation and validation events include duration
and result provenance. Log writes are fsync-backed.

`scripts/sage/sage-workflow-usage.py` summarizes observed successes and
failures by primitive version. It does not backfill unobserved executions.

## Mutation safety

Mutations are dry-run by default and require explicit `apply=True`.

Git mutation primitives require:

- the intended branch;
- clean working state before mutation;
- synchronized local and remote commits;
- exact changed and staged path scopes;
- diff validation;
- immediate commit and push;
- clean synchronized state afterward.

File writes that serve as evidence or state use temporary files, fsync, and
atomic replacement.

## Makefile composition

Aggregate Make targets are extended through prerequisites, not by inserting
recipe lines into an unknown target body.

The complete candidate Makefile MUST be written to a temporary file and
parsed with GNU Make for the new target and each modified aggregate target
before repository replacement. Candidate Makefile parsing is a required
mutation gate.

## Composition contract

Tracked workflow compositions live under `scripts/sage/workflows/`.

A composition:

- declares `PRIMITIVES_USED`;
- imports repository-owned primitives;
- contains ordering and capability-specific parameters only;
- does not import `subprocess` or reimplement command, Git, discovery,
  lifecycle, Makefile, validation, logging, or closeout helpers;
- stops on the first failed primitive.

## Evolution from evidence

A failure is classified against the primitive version that produced it.

When the root cause is in a primitive, the correction MUST update the
primitive, add a regression test, and increment its version. A wrapper-only
patch is prohibited for a primitive root cause.

Maturity is evidence-based:

- `pilot`: zero through two successful production executions;
- `validated`: three through nine successful production executions and no
  unresolved recurrence;
- `stable`: at least ten successful production executions with measured reuse.

No primitive is called stable because its code resembles prior one-off
helpers.

## Required measurements

SAGE records:

- primitive reuse ratio;
- direct-execution violations;
- successful executions and failures by primitive version;
- known-failure recurrences;
- wrapper-only defects;
- time to validated implementation;
- avoidable rework.

These measurements determine which primitives are hardened, replaced, or
deprecated.

## Least-authority safety foundations

Phase 2 adds four pilot primitives without activating autonomous mutation:

- `git.inspect` exposes only allowlisted local read-only Git inspection. It has no fetch, branch, stage, commit, push, ref, GitHub, or deployment method.
- `file.atomic-preserve-mode` performs same-directory temporary writes, file and directory fsync, atomic replacement, existing-mode preservation, allowed-root checks, and transactional rollback.
- `operator.git-proposal` emits one schema 1.0 operator-executed boundary containing exactly one secret-free command. It never executes the proposed command and blocks the next boundary until pasted output is verified.
- `git.safety-guardrail` rejects production-helper Git, GitHub, credential-inheritance, and deployment mutation paths. Mutating Git is permitted only in an explicitly declared isolated temporary-repository fixture.

The mixed-authority `git.repository` primitive remains available only to isolated temporary-repository tests and legacy operator-owned compositions until migrated. Downloaded implementation helpers must use `git.inspect` for repository state and must not import or instantiate `GitRepository`.

Every new Phase 2 primitive is linked to an approved capability-gap receipt and an approved component-selection manifest under `markdown/evidence-artifacts/SAGE-K3-OPERATING-CONTRACT-20260801-001/`. The framework remains a staged implementation; deployment and autonomous Git or GitHub mutation remain unauthorized.


## Decision and diagnosis primitives

Framework version 0.4.0 adds four pilot primitives:

- `authority.reconcile@1.0.0` keeps scoped source assertions separate from inference, reports conflicts and unknowns, and blocks mutation unless material authority is complete.
- `component.select@1.0.0` ranks repository-owned candidates using explicit ordered factors, retains rejected alternatives, and emits a versioned composition manifest without an opaque composite score.
- `capability.gap@1.0.0` proves configuration and composition are insufficient and requires operator approval before a new primitive may be implemented.
- `failure.diagnose@1.0.0` records direct evidence, expected and actual component paths, divergence, ownership, lesson use, recurrence, avoidable rework when measured, and a reusable correction before another corrective mutation.

These primitives construct typed in-memory records. Repository writes remain the responsibility of `file.atomic-preserve-mode`; Git and GitHub mutation remain operator-executed boundaries.


## Semantic outcome measurement

Framework version 0.5.0 adds `metrics.outcome@1.0.0`. The primitive:

- requires every schema 1.0 raw metric to be present, using `null` when measurement is unavailable;
- derives rates only after raw validation and never converts an unavailable value into zero;
- keeps authoritative repository Git mutations separate from disposable fixture Git mutations;
- rejects numerator values that cannot be a subset of their denominator;
- compares reports only when `workflow_class` matches and records the explicit comparability basis;
- emits no composite score.

Manual correction and operator intervention rates are activity shares: the count divided by commands executed plus that count. Other derived metrics use the numerator and denominator named in `sage-operating-contract-policy.json`. A zero denominator produces `null`, not zero.

The initial report at `markdown/evidence-artifacts/SAGE-K3-OPERATING-CONTRACT-20260801-001/outcome-metrics-baseline.json` preserves known measurements and leaves unavailable command, recurrence, intervention, fixture-mutation, elapsed-time, and rework measurements null. It is a baseline, not evidence of an improving trend.

## Root operating-contract composition

Framework version 0.6.0 adds no new primitive. The approved root-enforcement
manifest proves the existing primitives are sufficient and rejects an
autonomous mutation engine.

`scripts/sage/workflows/operating_contract.py` contains a thin two-boundary
composition. The pre-mutation sequence permits declared repository-content
writes and stops at one operator proposal. The post-operator sequence starts
with read-only verification of pasted output, then records outcome metrics and
evidence.

`make sage-operating-contract-check` runs positive, negative, ordering, and
fail-closed runtime tests plus the root policy guardrail. The target is a
dependency of the normal repository self-test and guardrail chains.
